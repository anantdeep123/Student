from django.shortcuts import render
import os
from huggingface_hub import InferenceClient
from django.shortcuts import render
from django.conf import settings
from openai import OpenAI


def chat_view(request):
    generated_message = None
    error_message = None

    if request.method == "POST":
        user_input = request.POST.get("prompt")

        if user_input:
            try:
                client = OpenAI(
                    base_url="https://router.huggingface.co/v1",
                    api_key=settings.HF_TOKEN,  # Make sure this env var is set
                )

                completion = client.chat.completions.create(
                    model="deepseek-ai/DeepSeek-V3.1:fireworks-ai",
                    messages=[
                        {
                            "role": "user",
                            "content": user_input,
                        }
                    ],
                )

                # ✅ fixed line
                generated_message = completion.choices[0].message.content

            except Exception as e:
                error_message = str(e)

    return render(
        request,
        "chat.html",
        {
            "generated_message": generated_message,
            "error_message": error_message,
        },
    )






